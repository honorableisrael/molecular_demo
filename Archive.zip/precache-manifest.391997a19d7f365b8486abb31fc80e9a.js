self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "b16e85abdc741556229a51bf9ef331b4",
    "url": "/index.html"
  },
  {
    "revision": "b91c3d51eb220b32c51a",
    "url": "/static/css/2.7a9f3b0b.chunk.css"
  },
  {
    "revision": "bb12f0973b0f84f10c2d",
    "url": "/static/css/main.ac489653.chunk.css"
  },
  {
    "revision": "b91c3d51eb220b32c51a",
    "url": "/static/js/2.58d31e04.chunk.js"
  },
  {
    "revision": "4ca87f944091c72a6f1e72a740e5698e",
    "url": "/static/js/2.58d31e04.chunk.js.LICENSE"
  },
  {
    "revision": "bb12f0973b0f84f10c2d",
    "url": "/static/js/main.4cb37921.chunk.js"
  },
  {
    "revision": "177d52efa2c7db582a05",
    "url": "/static/js/runtime-main.5b50bb1e.js"
  },
  {
    "revision": "f41e4eb15ade3b906010a76c63ddadff",
    "url": "/static/media/BRFirma-Regular.f41e4eb1.ttf"
  },
  {
    "revision": "769dae6b4c4177bddae718edc92456d0",
    "url": "/static/media/Groupedlines.769dae6b.png"
  },
  {
    "revision": "e1da2ba03d2577aa38064e59c301eb5c",
    "url": "/static/media/binoculars.e1da2ba0.png"
  },
  {
    "revision": "bbecbc85385ba15b83132afd2b0ad7df",
    "url": "/static/media/blueoverall.bbecbc85.png"
  },
  {
    "revision": "f4d2ad0e6d244991dfac1eeb899f567c",
    "url": "/static/media/dottedlines.f4d2ad0e.png"
  },
  {
    "revision": "ac02183933de139e2014006c37100672",
    "url": "/static/media/drilling-workers.ac021839.png"
  },
  {
    "revision": "43d1eefb784c17b2586e12e73642717d",
    "url": "/static/media/ethlene_flame.43d1eefb.png"
  },
  {
    "revision": "23a9f8a390eede78370cac180b4510e9",
    "url": "/static/media/greenbib.23a9f8a3.png"
  },
  {
    "revision": "5723c3dc9c7f62427ada5d28a968dc80",
    "url": "/static/media/labourers.5723c3dc.png"
  },
  {
    "revision": "e1da2ba03d2577aa38064e59c301eb5c",
    "url": "/static/media/leadengineers.e1da2ba0.jpg"
  },
  {
    "revision": "e0d80d123d55252aed7d0d906e09cbd5",
    "url": "/static/media/lightbulb.e0d80d12.png"
  },
  {
    "revision": "a74006f369890ce486cc275aadae2ddd",
    "url": "/static/media/manwithflame.a74006f3.png"
  },
  {
    "revision": "21697d675c4cf58b3db3f0ebb3ee00db",
    "url": "/static/media/oil-pipeline.21697d67.png"
  },
  {
    "revision": "23a9f8a390eede78370cac180b4510e9",
    "url": "/static/media/oilengineers.23a9f8a3.jpg"
  },
  {
    "revision": "a883f1ea63b79912d8cc18c66aa6161b",
    "url": "/static/media/pipelineindesert.a883f1ea.png"
  },
  {
    "revision": "38a8503917b3c70ec639f52d496346d1",
    "url": "/static/media/pipelineonice.38a85039.png"
  },
  {
    "revision": "a76b499df0935ab21eeb978ee102b51d",
    "url": "/static/media/pipelineonsand.a76b499d.png"
  },
  {
    "revision": "008426803ff912d0b6400f2cc3c3936c",
    "url": "/static/media/redoverall.00842680.png"
  },
  {
    "revision": "4493f269a71a24ba11964604f9f35f6a",
    "url": "/static/media/tractors.4493f269.png"
  },
  {
    "revision": "dd58a80d97a3de528070210eb780f5ae",
    "url": "/static/media/tropicalregion.dd58a80d.png"
  },
  {
    "revision": "f25c002f3282c6c56b3d33b071617ac2",
    "url": "/static/media/wallpapersty.f25c002f.png"
  },
  {
    "revision": "7cf25dbaba46f762209307f08948fe88",
    "url": "/static/media/welder.7cf25dba.png"
  },
  {
    "revision": "63bb9859875eba3ef7ab25b32b08c366",
    "url": "/static/media/weldingflame.63bb9859.png"
  },
  {
    "revision": "a9a812602ec1e4d4774ca44955f35fdc",
    "url": "/static/media/whitehelmet.a9a81260.png"
  }
]);